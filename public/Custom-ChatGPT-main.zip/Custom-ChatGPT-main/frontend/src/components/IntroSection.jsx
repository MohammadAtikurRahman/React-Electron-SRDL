import React from "react";
const IntroSection = () => {
  return (
    <div id="introsection">
      <h1>Introducing Idiya ChatGPT</h1>
      <p>
        Features:
        <ul>
          <li>Product name + price,sku,brand,weight,height,dimension</li>
          <li>Product name+ price+ shipping name</li>
          <li>Product name + shipping name</li>
          <li>recom + Product name = Recommended Product(max 10)</li>
          <li>sku,Product name = description</li>
        </ul>
      </p>
    </div>
  );
};

export default IntroSection;
